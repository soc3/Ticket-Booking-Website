<html>
<form method = "POST" action ="connect6.php">
Enter your Name : <br>
<input type="text" name="a" size="30"><br>
Enter the trainname : <br>
<input type="text" name="g" size="30"><br>
Enter Source station : <br>
<input type="text" name="h" size="30"><br>
Enter No. of Tickets to be cancelled : <br>
<input type="text" name="b" size="30"><br>
Enter 1st pnr number: <br>
<input type="text" name="c" size="30"><br>
Enter 2nd pnr number:  <br>
<input type="text" name="d" size="30"><br>
Enter 3rd pnr number:  <br>
<input type="text" name="e" size="30"><br>
Enter 4th pnr number: <br>
<input type="text" name="f" size="" ze="30"><br>
<input type="submit" value="submit"><br>
<input type = "reset" value="reset"><br>
</form>
 <style type="text/css">
body
{
background-image:url("train.jpg");
}
</style>
</html>

